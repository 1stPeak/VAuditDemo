<?php
date_default_timezone_set('UTC');
echo strtotime('Thu, 04 Aug 2016 19:30:31 GMT');

//   1470339031
// u_1470339033_v.png


?>
