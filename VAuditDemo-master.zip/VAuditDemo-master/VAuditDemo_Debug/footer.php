        <hr>
	   <div id="footer" class="pull-right">Copyright &copy; 2016 <a href="https://www.virzz.com/" target="_blank">Virink</a></div> 
    </div>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/bootswatch.js"></script>
  </body>
</html>
